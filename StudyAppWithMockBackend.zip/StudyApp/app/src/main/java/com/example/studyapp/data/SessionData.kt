package com.example.studyapp.data

var sessionIdCounter: Int = 0

interface SessionRepository {
    fun getSessions(): List<StudySession> // returns sessions
    fun createSession(session: StudySession) // creates the sessions
    fun joinSession(sessionId: String, userName: String): Boolean // adds name to session members
    fun leaveSession(sessionId: String, userName: String) // removes the names from members
    fun endSession(sessionId: String) // ends the session

    //Filter methods
    fun filterByCourse(course: String): List<StudySession>
    fun filterByBuilding(building: Building): List<StudySession>
    fun filterByRoom(room: String): List<StudySession>
}

class SessionRepositoryImpl : SessionRepository{
    private val sessions = mutableListOf<StudySession>()

    override fun getSessions(): List<StudySession>{
        return sessions
    }
    override fun createSession(session: StudySession){
        sessions.add(session)
    }
    override fun joinSession(sessionId: String, userName: String): Boolean{
        for (session in sessions){
            if (session.id == sessionId && session.memberNames.size < session.maxStudents){
                session.memberNames.add(userName)
                return true
            } else if (session.memberNames.size >= session.maxStudents){
                println("This session is full")
            }
        }
        return false
    }
    override fun leaveSession(sessionId: String, userName: String){
        for (session in sessions){
            if (session.id == sessionId){
                session.memberNames.remove(userName)
            }
        }
    }
    override fun endSession(sessionId: String){
        for (session in sessions){
            if (session.id == sessionId){
                sessions.remove(session)
            }
        }
    }

    override fun filterByCourse(course: String): List<StudySession>{
        val filteredList = sessions.filter { it.course == course }
        return filteredList
    }
    override fun filterByBuilding(building: Building): List<StudySession>{
        val filteredList = sessions.filter { it.building == building }
        return filteredList
    }
    override fun filterByRoom(room: String): List<StudySession>{
        val filteredList = sessions.filter { it.room == room }
        return filteredList
    }
}
