package com.example.studyapp.data

import java.time.LocalDateTime

// session data
data class StudySession(
    val id: String,
    val title: String,
    val course: String,
    val building: Building,
    val room: String,
    val startTime: LocalDateTime,
    val endTime: LocalDateTime,
    val maxStudents: Int,
    val hostName: String,
    var memberNames: MutableList<String>,
    val isEnded: Boolean = false
)
