package com.example.studyapp.mockBackend

import com.example.studyapp.data.Buildings
import com.example.studyapp.data.SessionRepository
import com.example.studyapp.data.SessionRepositoryImpl
import com.example.studyapp.data.StudySession
import com.example.studyapp.data.User
import java.time.LocalDateTime

fun mockBackend(){
    var session1 = StudySession(
        "1",
        "Computer Org Study Sesh",
        "Computer Organization",
        Buildings[0],
        "Third Floor of Library",
        LocalDateTime.of(2026, 11, 16, 17, 0),
        LocalDateTime.of(2026, 11, 16, 0, 0),
        4,
        "Ed",
        mutableListOf<String>("Julia, Ed")
    )

    var session2 = StudySession(
        "2",
        "Digital Electronics Study Sesh",
        "Digital Electronics",
        Buildings[1],
        "Howl's Hub",
        LocalDateTime.of(2026, 11, 18, 17, 0),
        LocalDateTime.of(2026, 11, 16, 19, 30),
        5,
        "Eddy",
        mutableListOf<String>("Ed, Edd, Eddy")
    )

    var sessions: SessionRepository = SessionRepositoryImpl()
    sessions.createSession(session1)
    sessions.createSession(session2)
}
